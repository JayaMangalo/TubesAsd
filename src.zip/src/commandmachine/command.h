#ifndef COMMAND_H
#define COMMAND_H

#include "../setup/setup.h"
extern List todo;

/****************** COMMAND TODO ******************/
void toDoCommand();

#endif