#include "command.h"

void toDoCommand() {
    displayToDo(todo);
};